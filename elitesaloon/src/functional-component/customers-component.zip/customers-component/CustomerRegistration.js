import React, { useState } from "react";
import PhoneInput from "react-phone-input-2";
import Swal from "sweetalert2";
import { FaEye, FaEyeSlash } from "react-icons/fa";
import "react-phone-input-2/lib/style.css";
import "./CustomerForm.css";
import { useNavigate } from "react-router-dom";


const CustomerRegistration = () => {
  const [form, setForm] = useState({
    customerName: "",
    email: "",
    phone: "",
    gender: "",
    dob: "",
    street: "",
    pincode: "",
    city: "",
    block: "",
    district: "",
    state: "",
    username: "",
    password: "",
    confirmPassword: "",
    profileImage: null,
  });

  const [errors, setErrors] = useState({});
  const [showPwd, setShowPwd] = useState(false);
  const [showCpwd, setShowCpwd] = useState(false);
  const navigate = useNavigate();


  /* ===== VALIDATION ===== */
  const validate = () => {
    let err = {};

    // Customer Name (NO NUMBERS)
    if (!form.customerName.trim())
      err.customerName = "Customer name is required";
    else if (!/^[A-Za-z\s]+$/.test(form.customerName))
      err.customerName = "Name should contain only letters";

    // Email
    if (!form.email)
      err.email = "Email is required";
    else if (!/^\S+@\S+\.\S+$/.test(form.email))
      err.email = "Enter valid email";

    // Phone
    if (!form.phone || form.phone.length < 10)
      err.phone = "Valid mobile number required";

    // Gender
    if (!form.gender)
      err.gender = "Gender is required";

    // DOB
    if (!form.dob)
      err.dob = "Date of birth is required";

    // Address
    if (!form.street)
      err.street = "Street is required";

    if (!form.pincode || form.pincode.length !== 6)
      err.pincode = "Valid pincode required";

    // Username
    if (!form.username)
      err.username = "Username is required";

    // Password (STRONG)
    const strongPassword =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#]).{8,}$/;

    if (!form.password)
      err.password = "Password is required";
    else if (!strongPassword.test(form.password))
      err.password =
        "Password must be 8+ chars, include uppercase, lowercase, number & special character";

    // Confirm Password
    if (!form.confirmPassword)
      err.confirmPassword = "Confirm password required";
    else if (form.password !== form.confirmPassword)
      err.confirmPassword = "Passwords do not match";

    // Profile Image
    if (!form.profileImage)
      err.profileImage = "Profile image is required";

    setErrors(err);
    return Object.keys(err).length === 0;
  };

  /* ===== HANDLE CHANGE ===== */
  const handleChange = (e) => {
    const { name, value, files } = e.target;

    // Customer name → letters only
    if (name === "customerName" && !/^[A-Za-z\s]*$/.test(value)) return;

    // Pincode → digits only
    if (name === "pincode" && !/^\d*$/.test(value)) return;

    setForm({ ...form, [name]: files ? files[0] : value });

    // Auto-fill address
    if (name === "pincode" && value.length === 6) {
      fetch(`https://api.postalpincode.in/pincode/${value}`)
        .then((res) => res.json())
        .then((data) => {
          if (data[0].Status === "Success") {
            const po = data[0].PostOffice[0];
            setForm((prev) => ({
              ...prev,
              city: po.Block,
              block: po.Name,
              district: po.District,
              state: po.State,
            }));
          }
        });
    }
  };

  /* ===== SUBMIT ===== */
 const handleSubmit = (e) => {
  e.preventDefault();

  if (!validate()) {
    Swal.fire("Validation Error", "Please fix the errors", "error");
    return;
  }

  Swal.fire({
    title: "OTP Sent 📩",
    text: "OTP has been sent to your Email / Mobile",
    icon: "success",
    confirmButtonText: "Verify OTP",
  }).then(() => {
    navigate("/customer-login-otp"); // ✅ OPEN OTP PAGE
  });

  console.log("Registration Data:", form);
};


  return (
    <div className="form-wrapper">
      <h2>EliteSalon Customer Registration</h2>

      <form onSubmit={handleSubmit}>
        {/* PERSONAL DETAILS */}
        <div className="form-section">
          <h3>Personal Details</h3>

          <div className="form-grid">
            <div className="form-group">
              <input
                name="customerName"
                placeholder="Customer Name"
                onChange={handleChange}
              />
              <small className="error-text">{errors.customerName}</small>
            </div>

            <div className="form-group">
              <input name="email" placeholder="Email" onChange={handleChange} />
              <small className="error-text">{errors.email}</small>
            </div>

            <div className="form-group">
              <PhoneInput
                country="in"
                value={form.phone}
                onChange={(phone) => setForm({ ...form, phone })}
              />
              <small className="error-text">{errors.phone}</small>
            </div>

            <div className="form-group">
              <select name="gender" onChange={handleChange}>
                <option value="">Gender</option>
                <option>Male</option>
                <option>Female</option>
                <option>Other</option>
              </select>
              <small className="error-text">{errors.gender}</small>
            </div>

            <div className="form-group">
              <input type="date" name="dob" onChange={handleChange} />
              <small className="error-text">{errors.dob}</small>
            </div>
          </div>
        </div>

        {/* ADDRESS */}
        <div className="form-section">
          <h3>Address</h3>

          <div className="form-grid">
            <div className="form-group">
              <input name="street" placeholder="Street" onChange={handleChange} />
              <small className="error-text">{errors.street}</small>
            </div>

            <div className="form-group">
              <input
                name="pincode"
                placeholder="Pincode"
                maxLength="6"
                onChange={handleChange}
              />
              <small className="error-text">{errors.pincode}</small>
            </div>

            <input value={form.city} placeholder="City" readOnly />
            <input value={form.block} placeholder="Block" readOnly />
            <input value={form.district} placeholder="District" readOnly />
            <input value={form.state} placeholder="State" readOnly />
          </div>
        </div>

        {/* CREDENTIALS */}
        <div className="form-section">
          <h3>Credentials</h3>

          <div className="form-grid">
            <div className="form-group">
              <input
                name="username"
                placeholder="Username"
                onChange={handleChange}
              />
              <small className="error-text">{errors.username}</small>
            </div>

            <div className="password-group">
              <input
                type={showPwd ? "text" : "password"}
                name="password"
                placeholder="Password"
                onChange={handleChange}
              />
              <span onClick={() => setShowPwd(!showPwd)}>
                {showPwd ? <FaEyeSlash /> : <FaEye />}
              </span>
              <small className="error-text">{errors.password}</small>
            </div>

            <div className="password-group">
              <input
                type={showCpwd ? "text" : "password"}
                name="confirmPassword"
                placeholder="Confirm Password"
                onChange={handleChange}
              />
              <span onClick={() => setShowCpwd(!showCpwd)}>
                {showCpwd ? <FaEyeSlash /> : <FaEye />}
              </span>
              <small className="error-text">{errors.confirmPassword}</small>
            </div>
          </div>
        </div>

        {/* IMAGE */}
        <div className="form-section">
          <h3>Profile Image</h3>
          <input
            type="file"
            accept="image/*"
            name="profileImage"
            onChange={handleChange}
          />
          <small className="error-text">{errors.profileImage}</small>
        </div>

        <button className="submit-btn">Register</button>
      </form>
    </div>
  );
};

export default CustomerRegistration;
