import React, { useState } from "react";
import Swal from "sweetalert2";
import { FaEye, FaEyeSlash } from "react-icons/fa";
import "./CustomerForm.css";

const CustomerLogin = () => {
  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const [errors, setErrors] = useState({});
  const [showPwd, setShowPwd] = useState(false);

  // ---------- VALIDATION ----------
  const validate = () => {
    let err = {};

    if (!form.email)
      err.email = "Email is required";
    else if (!/^\S+@\S+\.\S+$/.test(form.email))
      err.email = "Enter valid email";

    if (!form.password)
      err.password = "Password is required";

    setErrors(err);
    return Object.keys(err).length === 0;
  };

  // ---------- HANDLE CHANGE ----------
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  // ---------- SUBMIT ----------
  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validate()) {
      Swal.fire({
        icon: "error",
        title: "Login Failed",
        text: "Please fix the errors",
      });
      return;
    }

    // Dummy login success
    Swal.fire({
      icon: "success",
      title: "Login Successful 🎉",
      text: "Welcome to Elite Salon",
    });

    console.log("Login Data:", form);
  };

  return (
    <div className="form-wrapper" style={{ maxWidth: "420px" }}>
      <h2>EliteSalon Login</h2>

      <form onSubmit={handleSubmit}>

        {/* EMAIL */}
        <div className="form-section">
          <h3>Account Login</h3>

          <div className="form-row">
            <div>
              <input
                type="text"
                name="email"
                placeholder="Email"
                onChange={handleChange}
              />
              <small className="error-text">{errors.email}</small>
            </div>
          </div>

          {/* PASSWORD */}
          <div className="form-row">
            <div className="password-field">
              <input
                type={showPwd ? "text" : "password"}
                name="password"
                placeholder="Password"
                onChange={handleChange}
              />
              <span onClick={() => setShowPwd(!showPwd)}>
                {showPwd ? <FaEyeSlash /> : <FaEye />}
              </span>
            </div>
          </div>
          <small className="error-text">{errors.password}</small>
        </div>

        <button className="submit-btn">Login</button>
      </form>

      <div className="form-links">
        Don’t have an account? <span>Register</span>
      </div>
    </div>
  );
};

export default CustomerLogin;
