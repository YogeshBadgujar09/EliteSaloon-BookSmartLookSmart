import React, { useState } from "react";
import "./CustomerForm.css";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setError("Enter a valid email");
      return;
    }

    setError("");
    console.log("Reset link sent to:", email);
  };

  return (
    <div className="login-wrapper">
      <h2>Forgot Password</h2>

      <form className="login-form" onSubmit={handleSubmit}>
        <input
          type="email"
          placeholder="Enter registered email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        {error && <small className="error-text">{error}</small>}

        <button className="submit-btn">Send Reset Link</button>
      </form>
    </div>
  );
};

export default ForgotPassword;
